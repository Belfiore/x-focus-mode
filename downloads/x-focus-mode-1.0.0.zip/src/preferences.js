(() => {
  'use strict';

  const FocusX = globalThis.FocusX = globalThis.FocusX || {};
  const key = 'focusxPreferences';
  const pinChoices = Object.freeze(['home', 'following', 'bookmarks', 'notifications', 'messages', 'lists', 'profile', 'search']);
  const defaults = Object.freeze({
    enabled: true,
    textSize: 'large',
    hideCounts: false,
    pinnedNavigation: Object.freeze(['home', 'bookmarks']),
    theme: 'system',
    onboarded: false,
    debug: false
  });
  const choices = {
    textSize: ['comfortable', 'large', 'huge'],
    theme: ['system', 'light', 'dark']
  };
  const subscribers = new Set();
  let current = { ...defaults };
  let loading;
  let saving = Promise.resolve();

  const snapshot = () => ({ ...current, pinnedNavigation: [...current.pinnedNavigation] });

  function validate(value) {
    const clean = {};
    if (!value || typeof value !== 'object') return clean;
    for (const name of Object.keys(defaults)) {
      if (name === 'pinnedNavigation' && Array.isArray(value[name])) clean[name] = [...new Set(value[name].filter(item => pinChoices.includes(item)))];
      else if (choices[name]?.includes(value[name])) clean[name] = value[name];
      else if (typeof defaults[name] === 'boolean' && typeof value[name] === 'boolean') clean[name] = value[name];
    }
    return clean;
  }

  function update(value) {
    const next = { ...defaults, ...validate(value) };
    if (Object.keys(defaults).every(name => name === 'pinnedNavigation' ? next[name].join('|') === current[name].join('|') : next[name] === current[name])) return;
    current = next;
    for (const listener of subscribers) {
      try { listener(snapshot()); } catch (error) {
        if (current.debug) console.warn('[Focus] Preference listener failed.', error);
      }
    }
  }

  async function load() {
    if (!loading) {
      loading = (async () => {
        try {
          if (globalThis.chrome?.storage?.local) {
            const stored = await chrome.storage.local.get(key);
            update(stored[key]);
          }
        } catch (error) {
          if (current.debug) console.warn('[Focus] Local preferences unavailable.', error);
        }
      })();
    }
    await loading;
    return snapshot();
  }

  function save(patch) {
    const clean = validate(patch);
    saving = saving.then(async () => {
      await load();
      const next = { ...current, ...clean };
      if (globalThis.chrome?.storage?.local) {
        // Persist before notifying so options never claims an unsaved setting succeeded.
        await chrome.storage.local.set({ [key]: next });
      }
      update(next);
      return snapshot();
    });
    const result = saving;
    saving = saving.catch(() => {});
    return result;
  }

  function subscribe(listener) {
    if (typeof listener !== 'function') return () => {};
    subscribers.add(listener);
    return () => subscribers.delete(listener);
  }

  globalThis.chrome?.storage?.onChanged?.addListener((changes, area) => {
    if (area === 'local' && changes[key]) update(changes[key].newValue);
  });

  FocusX.preferences = Object.freeze({ defaults, pinChoices, load, save, subscribe });
})();
