(() => {
  'use strict';
  const FX = globalThis.FocusX;
  if (!FX || FX.running) return;
  FX.running = true;
  const { adapter, renderer, preferences, controls } = FX;
  const root = document.documentElement;
  let settings = { ...preferences.defaults };
  let models = [];
  let active = false;
  let current = null;
  let routeKey = '';
  let ui;
  let observer;
  let scheduled = false;
  let idleTimer;
  let scrollTimer;
  let resizeTimer;
  let navigatingUntil = 0;
  let pending = null;
  let recoveryTimer;
  let scrollAnimation;
  let sizeAnchor;
  let stopped = false;
  let transitionDeadline = 0;
  let transitionTimer;
  let hoverTimer;
  let hoveredArticle = null;
  let togglePending = false;
  const widePosts = new WeakMap();
  const mediaQuery = matchMedia('(prefers-color-scheme: dark)');
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
  const threadClasses = ['fx-thread-root', 'fx-thread-continuation', 'fx-reply'];

  function applyTheme() {
    root.dataset.focusxTheme = settings.theme === 'system' ? (mediaQuery.matches ? 'dark' : 'light') : settings.theme;
    root.dataset.focusxSize = settings.textSize;
    root.dataset.focusxCounts = settings.hideCounts ? 'hide' : 'show';
    root.dataset.focusxPinned = String(settings.pinnedNavigation.length > 0);
    root.dataset.focusxDebug = String(settings.debug);
    ui?.setContext({ supported: active });
  }

  function liveModels() {
    return models.filter(model => model.article.isConnected && model.article.getClientRects().length);
  }

  function nearest() {
    const center = innerHeight / 2;
    let best = null;
    let distance = Infinity;
    for (const model of liveModels()) {
      const rect = model.article.getBoundingClientRect();
      const d = rect.height > innerHeight && rect.top < center && rect.bottom > center
        ? 0 : Math.abs(rect.top + rect.height / 2 - center);
      if (d < distance) { distance = d; best = model; }
    }
    return best;
  }

  function markCurrent(model) {
    if (!model) return;
    if (current?.article !== model.article) current?.article.classList.remove('fx-current');
    current = model;
    current.article.classList.add('fx-current');
    const visible = liveModels();
    ui?.setContext({ supported: true, index: visible.indexOf(current) + 1, total: visible.length });
  }

  function cancelScrollAnimation(event) { cancelAnimationFrame(scrollAnimation); if (event?.type) navigatingUntil = 0; }

  function scrollToPosition(top, animate = true) {
    cancelScrollAnimation();
    top = Math.max(0, top);
    if (!animate || reducedMotion.matches) { scrollTo({ top, behavior: 'instant' }); return; }
    const start = scrollY;
    const began = performance.now();
    function frame(now) {
      const progress = Math.min(1, (now - began) / 220);
      const eased = 1 - Math.pow(1 - progress, 3);
      scrollTo({ top: start + (top - start) * eased, behavior: 'instant' });
      if (progress < 1) scrollAnimation = requestAnimationFrame(frame);
    }
    scrollAnimation = requestAnimationFrame(frame);
  }

  function align(model, fromEnd = false, animate = true) {
    const rect = model.article.getBoundingClientRect();
    const inset = 36;
    const target = rect.height < innerHeight - inset * 2
      ? scrollY + rect.top - (innerHeight - rect.height) / 2
      : scrollY + (fromEnd ? rect.bottom - innerHeight + inset : rect.top - inset);
    navigatingUntil = performance.now() + 450;
    scrollToPosition(target, animate);
  }

  function move(direction, direct = false) {
    if (!active) return;
    hoveredArticle = null;
    clearTimeout(hoverTimer);
    ui.setPostTarget(null);
    const selected = (performance.now() < navigatingUntil) && current?.article.isConnected ? current : nearest();
    if (!selected) return;
    markCurrent(selected);
    const rect = selected.article.getBoundingClientRect();
    const inset = 40;
    if (!direct && ((direction > 0 && rect.bottom > innerHeight + inset) || (direction < 0 && rect.top < -inset))) {
      const distance = direction > 0 ? Math.min(innerHeight * .72, rect.bottom - innerHeight + inset)
        : Math.max(-innerHeight * .72, rect.top - inset);
      navigatingUntil = performance.now() + 450;
      scrollToPosition(scrollY + distance);
      return;
    }
    const visible = liveModels();
    const index = visible.findIndex(item => item.article === selected.article);
    const next = visible[index + direction];
    if (next) {
      pending = null;
      markCurrent(next);
      align(next, !direct && direction < 0);
    } else if (direction > 0) {
      pending = { id: selected.id, direction };
      scrollBy({ top: Math.max(160, rect.bottom - innerHeight + 120), behavior: 'smooth' });
      clearTimeout(recoveryTimer);
      recoveryTimer = setTimeout(() => { pending = null; }, 4000);
    }
  }

  function deactivate() {
    cancelScrollAnimation();
    clearTimeout(transitionTimer);
    clearTimeout(hoverTimer);
    hoveredArticle = null;
    ui?.setPostTarget(null);
    active = false;
    pending = null;
    sizeAnchor = null;
    root.classList.remove('focusx-ready');
    for (const model of models) {
      model.article.classList.remove('fx-current', 'fx-wide-post', ...threadClasses);
      model.article.removeAttribute('data-focusx-index');
    }
    renderer.clearAll();
    renderer.clearPage();
    for (const key of ['focusxMode', 'focusxTransition', 'focusxTheme', 'focusxCounts', 'focusxDebug', 'focusxIdle', 'focusxPinned', 'focusxSize']) delete root.dataset[key];
    models = [];
    current = null;
    ui?.setEnabled(false);
    ui?.hideHint();
  }

  function scan() {
    scheduled = false;
    if (stopped) return;
    try {
      const route = adapter.getRoute();
      const key = route.path + location.search;
      if (key !== routeKey) {
        routeKey = key;
        transitionDeadline = performance.now() + 3000;
        clearTimeout(transitionTimer);
        hoveredArticle = null;
        clearTimeout(hoverTimer);
        cancelScrollAnimation();
        pending = null;
        sizeAnchor = null;
        current?.article.classList.remove('fx-current');
        current = null;
        ui?.setPostTarget(null);
        if (!active || !route.supported) deactivate();
      }
      if (!settings.enabled || !route.supported) { if (active) deactivate(); return; }
      const primary = adapter.findPrimary();
      ui?.setAccount?.(adapter.findAccount?.());
      const nextModels = primary ? adapter.collect(primary) : [];
      const nativeState = primary?.querySelector(adapter.selectors.timelineState);
      const hasNativeShell = Boolean(primary && adapter.findNavigation().some(item => ['home', 'bookmarks', 'profile'].includes(item.key)));
      const inTransition = !nextModels.length && !nativeState && performance.now() < transitionDeadline && (active || hasNativeShell);
      if (!nextModels.length && !nativeState && !inTransition) {
        if (active) deactivate();
        return;
      }
      if (inTransition) {
        // X may unmount the old column before mounting the next timeline.
        // Keep the reader controls and background while its own data loads.
        root.dataset.focusxTransition = 'true';
        root.classList.add('focusx-ready');
        active = true;
        if (primary) renderer.preparePage(primary);
        applyTheme();
        ui.setEnabled(true);
        ui.setContext({ total: 0, label: 'Loading posts' });
        clearTimeout(transitionTimer);
        transitionTimer = setTimeout(scheduleScan, Math.max(1, transitionDeadline - performance.now()));
        return;
      }
      clearTimeout(transitionTimer);
      delete root.dataset.focusxTransition;
      if (!primary) { if (active) deactivate(); return; }
      const oldId = current?.id;
      const previous = new Set(nextModels.map(model => model.article));
      for (const old of models) if (!previous.has(old.article)) {
        renderer.clear(old.article);
        old.article.classList.remove('fx-current', 'fx-wide-post', ...threadClasses);
      }
      if (!nextModels.length) current = null;
      models = nextModels;
      renderer.preparePage(primary);
      const threadRoot = route.type === 'thread' ? models.find(model => model.id === route.postId) : null;
      models.forEach((model, index) => {
        renderer.decorate(model, settings);
        model.article.classList.toggle('fx-wide-post', widePosts.has(model.article) && widePosts.get(model.article) === model.id);
        for (const cls of threadClasses) model.article.classList.remove(cls);
        if (threadRoot) model.article.classList.add(model.id === route.postId ? 'fx-thread-root'
          : model.authorHandle === threadRoot.authorHandle ? 'fx-thread-continuation' : 'fx-reply');
        if (settings.debug) model.article.dataset.focusxIndex = String(index + 1);
        else model.article.removeAttribute('data-focusx-index');
      });
      const wasActive = active;
      active = true;
      root.classList.add('focusx-ready');
      applyTheme();
      if (sizeAnchor) {
        const anchor = models.find(model => model.article === sizeAnchor.article);
        if (anchor) scrollToPosition(scrollY + anchor.article.getBoundingClientRect().top - sizeAnchor.top, false);
        sizeAnchor = null;
      }
      ui.setEnabled(true);
      ui.setContext({ total: models.length, label: route.type === 'bookmarks' ? 'Bookmarks' : '' });
      markCurrent(models.find(model => model.id === oldId) || nearest());
      if (pending) {
        const index = models.findIndex(model => model.id === pending.id);
        const next = index >= 0 ? models[index + pending.direction] : null;
        if (next) { pending = null; markCurrent(next); align(next); }
      }
      if (!wasActive && !settings.onboarded) {
        ui.showHint();
        preferences.save({ onboarded: true });
      }
    } catch (error) {
      if (settings.debug) console.warn('[Focus] Adapter failed; using original X.', error);
      deactivate();
    } finally {
      // This synchronous pass has reconciled the latest source DOM. Discard its
      // own annotation records so observing React's class/style writes cannot
      // turn our reversible annotations into another scan loop.
      observer?.takeRecords();
    }
  }

  function annotationsChanged(record) {
    if (!active || record.type !== 'attributes') return false;
    const node = record.target;
    if (record.attributeName === 'class') {
      return (record.oldValue || '').split(/\s+/).some(name => name.startsWith('fx-')
        && name !== 'fx-current'
        && (name !== 'fx-wide-post' || widePosts.has(node))
        && !node.classList.contains(name));
    }
    if (record.attributeName === 'style' && record.oldValue?.includes('--fx-')) {
      const before = document.createElement('span').style;
      before.cssText = record.oldValue;
      return Array.from(before).some(name => name.startsWith('--fx-') && (
        node.style.getPropertyValue(name) !== before.getPropertyValue(name)
        || node.style.getPropertyPriority(name) !== before.getPropertyPriority(name)));
    }
    return false;
  }

  function scheduleScan() {
    if (scheduled || stopped) return;
    scheduled = true;
    requestAnimationFrame(scan);
  }

  function isTyping(event) {
    return event.composedPath().some(node => node instanceof Element && (
      node.matches('input, textarea, select, video, [role="textbox"], [role="combobox"]')
      || (node.matches('[data-focusx-ui]') && Boolean(node.shadowRoot?.querySelector('dialog[open]')))
      || node.isContentEditable));
  }

  function nativeOverlayOpen() {
    return [...document.querySelectorAll('[role="dialog"], [role="menu"], dialog[open]')]
      .some(node => node.getClientRects().length > 0);
  }

  function openPost(original = false) {
    const model = current?.article.isConnected ? current : nearest();
    if (!model?.url) return;
    if (original) {
      preferences.save({ enabled: false });
      settings.enabled = false;
      deactivate();
    }
    const link = [...model.article.querySelectorAll('a[href]')].find(a => {
      try { return new URL(a.href).pathname === new URL(model.url, location.href).pathname; } catch { return false; }
    });
    if (link) link.click();
    else location.assign(model.url);
  }

  function action(name) {
    const model = current?.article.isConnected ? current : nearest();
    const button = model && adapter.parse(model.article)?.actions?.[name];
    if (button && !button.disabled && button.getAttribute('aria-disabled') !== 'true') button.click();
    else if (model) ui.announce(name === 'bookmark' ? 'Bookmark is available in the post menu.' : 'Open the post to use this action.');
  }

  function onCommand(command) {
    if (command === 'next' || command === 'previous') { move(command === 'next' ? 1 : -1, true); return; }
    if (command === 'original') {
      settings.enabled = false;
      preferences.save({ enabled: false });
      deactivate();
      return;
    }
    if (command === 'search') { ui.openSearch(); return; }
    const navigation = adapter.findNavigation();
    const destination = navigation.find(item => item.key === command);
    if (destination?.element) { destination.element.click(); return; }
    const paths = { home: '/home', following: '/home', notifications: '/notifications', messages: '/messages', bookmarks: '/i/bookmarks', lists: '/i/lists', search: '/explore', compose: '/compose/post' };
    if (paths[command]) location.assign(paths[command]);
    else if (command === 'profile') {
      ui.announce('Your profile is available in the original X navigation.');
      onCommand('original');
    }
  }

  function onSearch(query, filter) {
    const params = new URLSearchParams({ q: query, src: 'typed_query' });
    if (filter === 'latest') params.set('f', 'live');
    // Follow a real X route; the existing session renders the source results.
    const link = document.createElement('a');
    link.href = `/search?${params}`;
    link.hidden = true;
    link.dataset.focusxUi = 'true';
    document.body.append(link);
    link.click();
    link.remove();
  }

  function toggleWidth(article) {
    if (!active || !article?.isConnected) return;
    const model = models.find(item => item.article === article);
    if (!model) return;
    cancelScrollAnimation();
    const top = article.getBoundingClientRect().top;
    const wide = !article.classList.contains('fx-wide-post');
    article.classList.toggle('fx-wide-post', wide);
    if (wide) widePosts.set(article, model.id); else widePosts.delete(article);
    scrollToPosition(scrollY + article.getBoundingClientRect().top - top, false);
    markCurrent(model);
    hoveredArticle = article;
    ui.setPostTarget(article);
    ui.announce(wide ? 'Post widened.' : 'Post width restored.');
  }

  function onKey(event) {
    if (event.defaultPrevented || event.isComposing || isTyping(event)) return;
    const key = event.key.toLowerCase();
    if ((event.metaKey || event.ctrlKey) && key === 'k') {
      event.preventDefault(); event.stopImmediatePropagation(); ui.openSearch(); return;
    }
    if (event.metaKey || event.ctrlKey || event.altKey || nativeOverlayOpen()) return;
    if (key === 'f') {
      event.preventDefault(); event.stopImmediatePropagation();
      if (!event.repeat && !togglePending) {
        togglePending = true;
        preferences.save({ enabled: !settings.enabled }).catch(() => ui.announce('That change could not be saved. Please try again.'))
          .finally(() => { togglePending = false; });
      }
      return;
    }
    if (!active) return;
    if (event.composedPath().some(node => node instanceof Element && node.matches('button, a, [role="button"]')) && [' ', 'enter'].includes(key)) return;
    let handled = true;
    if (key === 'c' && !event.repeat) onCommand('compose');
    else if (key === 'o' && event.shiftKey) openPost(true);
    else if (key === 'escape' && adapter.getRoute().type === 'thread') {
      const back = document.querySelector('[data-testid="app-bar-back"]');
      if (back) back.click(); else history.back();
    }
    else if (key === '/' && !event.repeat) ui.openSearch();
    else if (key === 'w' && !event.repeat) toggleWidth((current?.article.isConnected ? current : nearest())?.article);
    else if (key === 'arrowdown') move(1, true);
    else if (key === 'arrowup') move(-1, true);
    else if (['j', ' '].includes(key)) move(1);
    else if (key === 'k') move(-1);
    else if (key === 'enter') openPost();
    else if (key === 'l' && !event.repeat) action('like');
    else if (key === 'b' && !event.repeat) action('bookmark');
    else if (key === 'r' && !event.repeat) action('reply');
    else handled = false;
    if (handled) { event.preventDefault(); event.stopImmediatePropagation(); }
  }

  function onPointer() {
    if (!active) return;
    if (root.dataset.focusxIdle !== 'false') root.dataset.focusxIdle = 'false';
    clearTimeout(idleTimer);
    idleTimer = setTimeout(() => { if (active) root.dataset.focusxIdle = 'true'; }, 2600);
  }

  function onScroll() {
    ui?.positionPostButton();
    clearTimeout(scrollTimer);
    scrollTimer = setTimeout(() => {
      if (!active || performance.now() < navigatingUntil) return;
      markCurrent(nearest());
    }, 100);
  }

  async function start() {
    settings = await preferences.load();
    if (stopped) return;
    ui = controls.create({ onCommand, onSearch, onExpand: toggleWidth, onSettingsChange: patch => preferences.save(patch), getSettings: () => settings });
    ui.setEnabled(false);
    preferences.subscribe(next => {
      if (active && next.textSize !== settings.textSize) {
        const anchor = current?.article.isConnected ? current : nearest();
        if (anchor) sizeAnchor = { article: anchor.article, top: anchor.article.getBoundingClientRect().top };
      }
      settings = next;
      if (!settings.enabled) deactivate(); else scheduleScan();
    });
    observer = new MutationObserver(records => {
      const sourceRecords = records.filter(record => record.target.isConnected && !record.target.closest?.('[data-focusx-ui]'));
      // React replaces entire className/style attributes on hover and theme
      // updates. Repair lost geometry/type annotations in this mutation turn,
      // before the next paint, rather than waiting for unrelated post content.
      if (sourceRecords.some(annotationsChanged)) { scan(); return; }
      if (sourceRecords.some(record => {
        if (record.type === 'attributes' && ['class', 'style'].includes(record.attributeName)) return false;
        return record.type !== 'childList' || [...record.addedNodes, ...record.removedNodes].some(node =>
          node.nodeType !== 1 || !node.matches?.('[data-focusx-ui]'));
      })) scheduleScan();
    });
    observer.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeOldValue: true, attributeFilter: ['data-testid', 'href', 'src', 'aria-pressed', 'class', 'style'] });
    document.addEventListener('keydown', onKey, true);
    document.addEventListener('pointermove', onPointer, { passive: true });
    document.addEventListener('focusin', onPointer);
    const targetPost = event => {
      if (!active || event.target.closest?.('[data-focusx-ui]')) return;
      const article = event.target.closest?.('.fx-post') || null;
      clearTimeout(hoverTimer);
      if (article) {
        if (hoveredArticle !== article) { hoveredArticle = article; ui.setPostTarget(article); }
      } else {
        hoverTimer = setTimeout(() => {
          hoveredArticle = null;
          ui.setPostTarget(null);
        }, 140);
      }
    };
    document.addEventListener('pointerover', targetPost, { passive: true });
    document.addEventListener('focusin', targetPost);
    window.addEventListener('wheel', cancelScrollAnimation, { passive: true });
    window.addEventListener('touchstart', cancelScrollAnimation, { passive: true });
    window.addEventListener('pointerdown', cancelScrollAnimation, { passive: true });
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('popstate', scheduleScan);
    window.addEventListener('hashchange', scheduleScan);
    window.addEventListener('pageshow', scheduleScan);
    window.navigation?.addEventListener('navigatesuccess', scheduleScan);
    window.addEventListener('resize', () => { clearTimeout(resizeTimer); resizeTimer = setTimeout(() => { scheduleScan(); ui.positionPostButton(); }, 120); }, { passive: true });
    mediaQuery.addEventListener('change', applyTheme);
    scan();
  }
  if (document.body) start();
  else document.addEventListener('DOMContentLoaded', start, { once: true });
})();
