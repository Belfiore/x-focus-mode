/* X-specific markup belongs here. Source nodes remain X's source of truth. */
(() => {
  'use strict';
  const FocusX = globalThis.FocusX = globalThis.FocusX || {};
  const selectors = Object.freeze({
    article: 'article[data-testid="tweet"]',
    primary: '[data-testid="primaryColumn"]',
    timelineState: '[data-testid="emptyState"], [role="progressbar"]',
    cell: '[data-testid="cellInnerDiv"]',
    text: '[data-testid="tweetText"]',
    author: '[data-testid="User-Name"]',
    avatar: '[data-testid="Tweet-User-Avatar"], [data-testid^="UserAvatar-Container"]',
    photo: '[data-testid="tweetPhoto"]',
    video: '[data-testid="videoPlayer"], [data-testid="videoComponent"]',
    quote: '[data-testid="quoteTweet"], [data-testid="quotedTweet"]',
    card: '[data-testid="card.wrapper"], [data-testid="card.layoutLarge.media"], [data-testid="card.layoutSmall.media"]',
    note: '[data-testid="birdwatch-pivot"], [data-testid="birdwatch-pivot-wrapper"], [data-testid="communityNote"]',
    poll: '[data-testid="poll"], [data-testid="cardPoll"], [data-testid="poll-vote"]',
    sensitive: '[data-testid="sensitiveMediaInterstitial"], [data-testid="sensitiveMediaWarning"], [data-testid="sensitive_media"], [aria-label*="sensitive content" i], [aria-label*="sensitive media" i]',
    promoted: '[data-testid="placementTracking"], [data-testid="promotedIndicator"]',
    promotedLabel: '[data-testid="promotedIndicator"]',
    menu: '[data-testid="caret"]',
    reply: '[data-testid="reply"]',
    repost: '[data-testid="retweet"], [data-testid="unretweet"]',
    like: '[data-testid="like"], [data-testid="unlike"]',
    bookmark: '[data-testid="bookmark"], [data-testid="removeBookmark"]',
    share: '[data-testid="share"], button[aria-label="Share post"], button[aria-label="Share"]',
    context: '[data-testid="socialContext"]',
    sidebar: '[data-testid="sidebarColumn"]',
    composer: '[data-testid="tweetTextarea_0"], [data-testid="tweetButtonInline"], [data-testid="tweetButton"], [data-testid="toolBar"]',
    composerToolbar: '[data-testid="toolBar"]',
    pageHeader: 'form[role="search"], header, [data-testid="app-bar-back"], [data-testid="ScrollSnap-List"], [role="tablist"]',
    pageHeading: 'h1, h2, [role="heading"][aria-level="1"], [role="heading"][aria-level="2"]',
    account: '[data-testid="SideNav_AccountSwitcher_Button"], [data-testid="DashButton_ProfileIcon_Link"], [data-testid="AppTabBar_Profile_Link"], button[aria-label="Account menu"], [role="button"][aria-label="Account menu"]',
    home: '[data-testid="AppTabBar_Home_Link"]',
    notifications: '[data-testid="AppTabBar_Notifications_Link"]',
    messages: '[data-testid="AppTabBar_DirectMessage_Link"]',
    profile: '[data-testid="AppTabBar_Profile_Link"]',
    search: '[data-testid="AppTabBar_Explore_Link"]',
    compose: '[data-testid="SideNav_NewTweet_Button"]'
  });

  const asArray = (root, selector) => Array.from(root.querySelectorAll(selector));
  const compact = node => (node?.textContent || '').replace(/\s+/g, ' ').trim();
  const directOwner = (node, article) => node && node.closest(selectors.article) === article;

  function getRoute(input = globalThis.location?.href || 'https://x.com/home') {
    let url;
    try { url = new URL(input, globalThis.location?.href || 'https://x.com'); }
    catch { return { supported: false, type: 'other', path: '', postId: null, handle: null }; }
    const path = url.pathname.replace(/\/$/, '') || '/';
    const thread = path.match(/^\/([^/]+)\/status\/(\d+)$/);
    const legacyThread = path.match(/^\/i\/web\/status\/(\d+)$/);
    // Native photo/video viewers are deliberately not treated as a fresh thread.
    const type = path === '/home' ? 'home' : path === '/search' ? 'search' : /^\/i\/(?:bookmarks(?:\/\d+)?|history)$/.test(path) ? 'bookmarks' : /^\/i\/lists\/\d+$/.test(path) ? 'list' : thread || legacyThread ? 'thread' : 'other';
    return {
      supported: ['x.com', 'www.x.com', 'twitter.com', 'www.twitter.com'].includes(url.hostname) && type !== 'other',
      type, path, postId: thread?.[2] || legacyThread?.[1] || null,
      handle: thread?.[1] || null
    };
  }

  function findQuotes(article) {
    const author = article.querySelector(selectors.author);
    const explicit = asArray(article, selectors.quote).filter(node => directOwner(node, article));
    const semantic = asArray(article, '[role="link"]').filter(node => {
      if (!directOwner(node, article) || node === article || node.contains(author)) return false;
      if (node.matches(selectors.card) || node.closest(selectors.card)) return false;
      return Boolean(node.querySelector(`${selectors.text}, ${selectors.author}`));
    });
    const candidates = [...new Set([...explicit, ...semantic])];
    // A nested role=link inside a quote is still part of that single quote.
    return candidates.filter(node => !candidates.some(other => other !== node && other.contains(node)));
  }

  function parse(article) {
    if (!article?.matches?.(selectors.article)) return null;
    const quotes = findQuotes(article);
    const isOwn = node => directOwner(node, article) && !quotes.some(quote => quote.contains(node));
    const own = selector => asArray(article, selector).find(isOwn) || null;
    const ownAll = selector => asArray(article, selector).filter(isOwn);
    const authorElement = own(selectors.author);
    const textElement = own(selectors.text);
    const time = own('time');
    const statusLink = time?.closest('a[href*="/status/"]') || own('a[href*="/status/"]');
    const statusMatch = statusLink?.getAttribute('href')?.match(/\/([^/]+)\/status\/(\d+)/);
    const authorLinks = authorElement ? asArray(authorElement, 'a[href]') : [];
    const profileLink = authorLinks.find(link => /^\/[A-Za-z0-9_]+\/?$/.test(link.getAttribute('href') || ''));
    const handleText = authorElement ? asArray(authorElement, 'span').map(compact).find(value => /^@[A-Za-z0-9_]+$/.test(value)) : null;
    const authorHandle = handleText || (profileLink ? `@${profileLink.getAttribute('href').split('/')[1]}` : statusMatch ? `@${statusMatch[1]}` : '');
    const author = compact(profileLink) || authorHandle;
    const actions = Object.fromEntries(['reply', 'repost', 'like', 'bookmark', 'share'].map(key => [key, own(selectors[key])]));
    const firstAction = actions.reply || actions.like || actions.repost;
    const actionRow = firstAction?.closest('[role="group"]') || null;
    const videos = ownAll(selectors.video).filter((node, _index, nodes) => !nodes.some(other => other !== node && other.contains(node)));
    const photos = ownAll(selectors.photo).filter(node => !videos.some(video => video.contains(node)));
    const media = [...photos.map(element => ({ element, type: 'photo' })), ...videos.map(element => ({ element, type: 'video' }))];
    const notes = ownAll(selectors.note).filter((node, _index, nodes) => !nodes.some(other => other !== node && other.contains(node)));
    const pollOption = own('[role="radio"]');
    const poll = own(selectors.poll) || pollOption?.closest('[role="radiogroup"]') || null;
    const text = textElement?.innerText ?? textElement?.textContent ?? '';
    const id = statusMatch?.[2] || article.getAttribute('data-tweet-id') || null;
    const promotedLabel = own(selectors.promotedLabel)
      || ownAll('[data-testid="placementTracking"]').find(node => !node.contains(textElement) && !node.contains(authorElement))
      || ownAll('span').find(node => !textElement?.contains(node) && !authorElement?.contains(node)
        && !node.closest('[role="group"]') && /^(?:Promoted|Ad)$/.test(compact(node))) || null;
    // An unrecognizable/loading article must not trigger page-wide transformation.
    if (!authorElement && !textElement && !media.length && !quotes.length) return null;
    return {
      article, id, url: statusMatch ? `https://x.com/${statusMatch[1]}/status/${statusMatch[2]}` : null,
      author, authorHandle, authorElement, text, textElement, time, statusLink,
      actions, actionRow: actionRow && article.contains(actionRow) ? actionRow : firstAction?.parentElement?.parentElement || null,
      media, quote: quotes[0] || null, quotes,
      cell: article.closest(selectors.cell), avatar: own(selectors.avatar),
      context: own(selectors.context), notes, poll, card: own(selectors.card), menu: own(selectors.menu),
      sensitive: own(selectors.sensitive),
      promoted: Boolean(promotedLabel || own(selectors.promoted) || article.closest(selectors.promoted)), promotedLabel,
      isReply: /replying to/i.test(compact(own('[data-testid="replyingTo"]')))
    };
  }

  function findPrimary(root = document) {
    return root.querySelector(selectors.primary) || root.querySelector('main[role="main"]') || root.querySelector('main');
  }

  function collect(root = document) {
    const primary = root === document ? findPrimary(root) || root : root;
    const articles = primary.matches?.(selectors.article) ? [primary] : asArray(primary, selectors.article);
    return articles.filter(article => !article.closest('[role="dialog"], [aria-modal="true"]') && !article.parentElement?.closest(selectors.article)).map(parse).filter(Boolean);
  }

  function findAccount(root = document) {
    // Match account controls only: an author avatar is never the signed-in user.
    const candidates = asArray(root, selectors.account).filter(node =>
      !node.closest(`${selectors.article}, [role="dialog"], [aria-modal="true"]`));
    const primary = root.matches?.(selectors.primary) ? root : findPrimary(root);
    const timeline = primary?.querySelector(`[role="region"], ${selectors.article}, ${selectors.timelineState}`);
    // Some mobile app bars expose only an avatar link, without a stable testid.
    // Restrict that fallback to the header area before the source timeline.
    const headerAvatar = timeline && asArray(primary, 'a[href]').find(link => {
      if (!link.querySelector('img') || link.closest(`${selectors.article}, [role="region"], [role="dialog"], [aria-modal="true"], ${selectors.composer}`)) return false;
      if (!(link.compareDocumentPosition(timeline) & 4)) return false;
      try {
        const href = new URL(link.getAttribute('href'), globalThis.location?.href || 'https://x.com');
        return href.origin === new URL(globalThis.location?.href || 'https://x.com').origin
          && /^\/[A-Za-z0-9_]{1,15}\/?$/.test(href.pathname)
          && !/^\/(?:home|explore|search|settings|notifications|messages)\/?$/.test(href.pathname);
      } catch { return false; }
    });
    const element = candidates.find(node => node.querySelector('img')) || headerAvatar || candidates[0];
    if (!element) return null;
    const image = element.querySelector('img');
    return {
      element,
      imageUrl: image?.currentSrc || image?.getAttribute('src') || '',
      label: element.getAttribute('aria-label') || image?.getAttribute('alt') || 'Account menu'
    };
  }

  function findTimelineRefresh(root = document) {
    return asArray(root, 'button, [role="button"]').filter(node =>
      !node.closest(`${selectors.article}, [role="dialog"], [aria-modal="true"]`)
      && /^(?:show|see)\s+\d+\s+(?:new\s+)?(?:posts?|tweets?)$/i.test(compact(node)));
  }

  function findNavigation(root = document) {
    const entries = [
      ['home', 'Home', selectors.home],
      ['notifications', 'Notifications', selectors.notifications],
      ['messages', 'Messages', selectors.messages],
      ['bookmarks', 'Bookmarks', 'a[href="/i/bookmarks"], a[href="/i/history"]'],
      ['lists', 'Lists', 'a[href="/i/lists"], a[href$="/lists"]'],
      ['profile', 'Profile', selectors.profile],
      ['search', 'Search', selectors.search],
      ['compose', 'Write a post', selectors.compose]
    ];
    const links = entries.map(([key, label, selector]) => {
      const candidates = asArray(root, selector).filter(node => !node.closest(`${selectors.article}, [role="dialog"], [aria-modal="true"]`));
      const element = key === 'bookmarks'
        ? candidates.find(node => node.getAttribute('href') === '/i/history') || candidates[0]
        : candidates[0];
      return element ? { key, label, href: element.getAttribute('href'), element } : null;
    }).filter(Boolean);
    const following = asArray(root, '[role="tab"]').find(node => /^following$/i.test(compact(node)));
    if (following) links.splice(1, 0, { key: 'following', label: 'Following', href: null, element: following });
    return links;
  }

  FocusX.adapter = Object.freeze({ selectors, parse, collect, getRoute, findPrimary, findNavigation, findAccount, findTimelineRefresh });
})();
