(() => {
  'use strict';
  const FocusX = globalThis.FocusX = globalThis.FocusX || {};
  const titles = { home: 'Home', following: 'Following', bookmarks: 'Bookmarks', notifications: 'Notifications', messages: 'Messages', lists: 'Lists', profile: 'Profile', search: 'Search' };
  const searchIcon = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/></svg>';
  const accountIcon = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="3.5"/><path d="M5 21v-2a7 7 0 0 1 14 0v2"/></svg>';
  const widthIcon = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 5H3v6m0-6 7 7m5 7h6v-6m0 6-7-7"/></svg>';
  const styles = `
    :host { all: initial; --bg: #fafaf8; --fg: #22221f; --muted: #73736d; --line: #e5e5df; --hover: #edede8; font: 14px/1.45 -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif; color: var(--fg); color-scheme: light; }
    @media (prefers-color-scheme: dark) { :host(:not([data-theme="light"])) { --bg: #111110; --fg: #efefe9; --muted: #a19f97; --line: #30302c; --hover: #242420; color-scheme: dark; } }
    :host([data-theme="dark"]) { --bg: #111110; --fg: #efefe9; --muted: #a19f97; --line: #30302c; --hover: #242420; color-scheme: dark; }
    * { box-sizing: border-box; }
    button { color: inherit; border: 0; background: transparent; cursor: pointer; }
    button:focus-visible, input:focus-visible, select:focus-visible { outline: 2px solid var(--fg); outline-offset: 3px; }
    [hidden] { display: none !important; }
    .sr { position: fixed; width: 1px; height: 1px; overflow: hidden; clip-path: inset(50%); white-space: nowrap; }
    .toolbar { position: fixed; z-index: 2147483600; top: 24px; right: 30px; display: flex; gap: 6px; align-items: center; pointer-events: auto; }
    .toolbar button { height: 36px; min-width: 36px; padding: 0 10px; border-radius: 4px; opacity: .56; transition: opacity 180ms ease-out, background 180ms ease-out; }
    .toolbar button:hover, .toolbar button:focus-visible { opacity: 1; background: var(--hover); }
    .toolbar .more { font-size: 20px; line-height: 1; letter-spacing: 1px; }
    .pinned { position: fixed; z-index: 2147483598; left: 20px; top: 50%; transform: translateY(-50%); display: flex; flex-direction: column; gap: 7px; width: 105px; max-height: 65vh; overflow-y: auto; }
    .pinned button { text-align: left; padding: 9px 8px; min-height: 36px; font-size: 12px; color: var(--muted); border-left: 1px solid transparent; transition: color 160ms ease-out; }
    .pinned button:hover, .pinned button:focus-visible, .pinned button[aria-current="page"] { color: var(--fg); }
    .pinned button[aria-current="page"] { border-left-color: var(--fg); }
    .pinned .customize { font-size: 18px; width: 36px; opacity: .6; }
    .type-scale { display: flex; align-items: center; gap: 1px; margin-right: 13px; }
    .toolbar .type-scale button { min-width: 30px; width: 30px; padding: 0; color: var(--muted); border-radius: 0; opacity: 1; border-bottom: 1px solid transparent; }
    .toolbar .type-scale button[aria-pressed="true"] { color: var(--fg); border-bottom-color: var(--fg); }
    .account { position: fixed; z-index: 2147483600; top: 24px; left: 28px; width: 36px; height: 36px; padding: 0; border: 1px solid var(--line); border-radius: 50%; display: grid; place-items: center; background: var(--bg); overflow: hidden; }
    .account img { width: 100%; height: 100%; object-fit: cover; border-radius: inherit; }
    .account svg { width: 24px; height: 24px; fill: none; stroke: currentColor; stroke-width: 1.5; }
    .post-navigation { position: fixed; z-index: 2147483598; left: 28px; bottom: 28px; display: flex; gap: 6px; }
    .post-navigation button { background: var(--bg); width: 36px; height: 36px; font-size: 20px; color: var(--muted); border: 1px solid var(--line); border-radius: 3px; }
    .post-navigation button:hover { color: var(--fg); border-color: var(--muted); }
    .pin-list { padding: 0 24px 24px; }
    .pin-list label { display: flex; align-items: center; justify-content: space-between; min-height: 47px; font-size: 13px; cursor: pointer; }
    .hint { position: fixed; z-index: 2147483599; bottom: 33px; left: 50%; transform: translateX(-50%); display: flex; align-items: center; gap: 14px; padding: 12px 14px 12px 18px; color: var(--muted); background: var(--bg); border: 1px solid var(--line); border-radius: 4px; font-size: 12px; }
    .hint button { font-size: 17px; color: var(--muted); padding: 0 3px; }
    kbd { font: inherit; font-size: 11px; color: var(--muted); white-space: nowrap; }
    .hint kbd { color: var(--fg); margin: 0 3px; }
    dialog { position: fixed; inset: 14vh 0 auto; width: min(440px, calc(100vw - 40px)); max-height: min(620px, 75vh); margin: 0 auto; padding: 0; color: var(--fg); background: var(--bg); border: 1px solid var(--line); border-radius: 7px; box-shadow: 0 16px 70px #00000013; overflow-y: auto; overscroll-behavior: contain; }
    dialog::backdrop { background: #00000024; }
    .dialog-header { display: flex; align-items: center; justify-content: space-between; gap: 15px; padding: 21px 23px 15px; }
    h2 { margin: 0; font-size: 13px; font-weight: 500; letter-spacing: .01em; }
    .close, .back { color: var(--muted); font-size: 12px; padding: 5px; border-radius: 3px; }
    .close:hover, .back:hover { color: var(--fg); background: var(--hover); }
    .command-list { padding: 0 12px 12px; }
    .command { display: flex; align-items: center; justify-content: space-between; width: 100%; text-align: left; padding: 10px 12px; border-radius: 3px; font-size: 13px; }
    .command:hover, .command:focus-visible { background: var(--hover); }
    input[type="checkbox"] { appearance: none; width: 30px; height: 18px; flex-shrink: 0; margin: 0; border-radius: 10px; background: var(--muted); border: 1px solid var(--muted); position: relative; cursor: pointer; }
    input[type="checkbox"]::after { content: ""; position: absolute; width: 12px; height: 12px; top: 2px; left: 2px; border-radius: 50%; background: var(--bg); transition: transform 160ms ease-out; }
    input[type="checkbox"]:checked { background: var(--fg); }
    input[type="checkbox"]:checked::after { transform: translateX(12px); }
    .toolbar svg, .search-form svg, .expand-post svg { width: 19px; height: 19px; fill: none; stroke: currentColor; stroke-width: 1.5; }
    .toolbar .search-button { display: grid; place-items: center; padding: 8px; }
    dialog { width: min(440px, calc(100vw - 32px)); inset-block-start: 12vh; border-radius: 10px; }
    dialog[data-view="search"] { width: min(680px, calc(100vw - 32px)); }
    .search-form { padding: 5px 24px 20px; }
    .search-field { display: flex; align-items: center; gap: 12px; border-bottom: 1px solid var(--line); padding: 10px 0 16px; }
    .search-field > svg { flex: 0 0 20px; color: var(--muted); }
    .search-input { min-width: 0; width: 100%; padding: 0; color: var(--fg); background: transparent; border: 0; outline: none; font-size: 20px; line-height: 1.35; border-radius: 0; }
    .search-input::placeholder { color: var(--muted); }
    .search-field:focus-within { border-color: var(--fg); }
    .search-input:focus-visible { outline: none; }
    [data-view="search"] .search-form { padding: 10px 32px 30px; }
    [data-view="search"] .search-input { font-size: clamp(25px, 4vw, 36px); letter-spacing: -.035em; }
    [data-view="search"] .dialog-header { padding: 26px 32px 12px; }
    .search-submit { width: 32px; height: 32px; flex: 0 0 32px; font-size: 23px; border-radius: 3px; }
    .search-submit:disabled { opacity: .25; cursor: default; }
    .search-meta { display: flex; justify-content: space-between; align-items: center; margin-top: 20px; gap: 12px; }
    .search-filters { display: flex; gap: 20px; }
    .search-filters button { padding: 7px 0; font-size: 12px; color: var(--muted); border-bottom: 1px solid transparent; }
    .search-filters button[aria-pressed="true"] { color: var(--fg); border-color: var(--fg); }
    .search-hint { margin: 20px 0 0; color: var(--muted); font-size: 12px; line-height: 1.7; }
    .interface-toggle { display: flex; align-items: center; justify-content: space-between; gap: 20px; padding: 13px 12px; font-size: 13px; cursor: pointer; }
    .interface-label { display: flex; align-items: center; gap: 12px; }
    .appearance { display: flex; align-items: center; justify-content: space-between; gap: 20px; padding: 12px; font-size: 13px; }
    .theme-choices { display: flex; padding: 3px; gap: 3px; border: 1px solid var(--line); border-radius: 6px; }
    .theme-choices button { display: flex; align-items: center; gap: 7px; min-height: 30px; padding: 5px 9px; font-size: 12px; border-radius: 3px; color: var(--muted); }
    .theme-choices button[aria-pressed="true"] { background: var(--hover); color: var(--fg); }
    .swatch { width: 10px; height: 10px; border: 1px solid #8888; border-radius: 50%; }
    .swatch-dark { background: #111210; } .swatch-light { background: #fdfcf9; }
    .expand-post { position: fixed; z-index: 2147483597; width: 32px; height: 32px; display: grid; place-items: center; color: var(--muted); background: var(--bg); border: 1px solid var(--line); border-radius: 4px; opacity: .8; }
    .expand-post:hover, .expand-post:focus-visible { color: var(--fg); opacity: 1; }
    .search-view { position: fixed; left: 160px; top: 33px; max-width: calc(100vw - 440px); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; padding: 3px 0; color: var(--muted); font-size: 12px; text-align: left; }
    @media (max-width: 700px) { .account { top: 13px; left: 18px; } .pinned { left: 12px; top: 61px; transform: none; width: calc(100vw - 24px); max-height: 40px; flex-direction: row; gap: 0; overflow-x: auto; } .pinned button { white-space: nowrap; font-size: 11px; padding: 8px 6px; border-left: 0; } .pinned button[aria-current="page"] { border-bottom: 1px solid var(--fg); } .type-scale { margin-right: 0; } .toolbar { top: 13px; right: 10px; gap: 0; } .post-navigation { left: 16px; bottom: 16px; } .search-view { left: 20px; top: 106px; max-width: calc(100vw - 40px); } dialog { inset-block-start: 9vh; max-height: 82vh; } .hint { bottom: 20px; } }
    @media (prefers-reduced-motion: reduce) { *, *::after { transition: none !important; scroll-behavior: auto !important; } }
  `;
  function create({ onCommand = () => {}, onSearch = () => {}, onExpand = () => {}, onSettingsChange = () => {}, getSettings = () => ({}) } = {}) {
    const host = document.createElement('div');
    host.id = 'focusx-controls';
    host.dataset.focusxUi = 'true';
    const shadow = host.attachShadow({ mode: 'open' });
    shadow.innerHTML = `<style>${styles}</style>
      <button class="account" type="button" aria-label="Open account menu" title="Open account menu" hidden></button>
      <nav class="pinned" aria-label="Pinned navigation"></nav>
      <button class="search-view" type="button" hidden></button>
      <div class="post-navigation" aria-label="Move through posts"><button type="button" data-command="previous" aria-label="Previous post" title="Previous post (↑)">↑</button><button type="button" data-command="next" aria-label="Next post" title="Next post (↓)">↓</button></div>
      <div class="toolbar" aria-label="Reading controls">
        <div class="type-scale" role="group" aria-label="Text size"><button type="button" data-size="comfortable" aria-label="Comfortable text" title="Comfortable text" style="font-size:12px">A</button><button type="button" data-size="large" aria-label="Large text" title="Large text" style="font-size:16px">A</button><button type="button" data-size="huge" aria-label="Huge text" title="Huge text" style="font-size:20px">A</button></div>
        <button class="search-button" type="button" aria-label="Search X" title="Search X (⌘ / Ctrl K)">${searchIcon}</button>
        <button class="more" type="button" aria-label="Open reading menu" aria-haspopup="dialog" title="Reading menu">···</button>
      </div>
      <button class="expand-post" type="button" aria-label="Widen post" title="Widen post (W)" aria-pressed="false" hidden>${widthIcon}</button>
      <div class="hint" role="status" hidden><span>Scroll to read. <kbd>↓</kbd> for the next post.</span><button type="button" aria-label="Dismiss reading hint">×</button></div>
      <dialog aria-labelledby="focusx-dialog-title"></dialog>
      <span class="sr context"></span><span class="sr announcement" role="status" aria-live="polite" aria-atomic="true"></span>`;
    const dialog = shadow.querySelector('dialog');
    const pinned = shadow.querySelector('.pinned');
    const menuButton = shadow.querySelector('.more');
    const expand = shadow.querySelector('.expand-post');
    const hint = shadow.querySelector('.hint');
    const accountButton = shadow.querySelector('.account');
    let account = null, accountImage = null;
    let enabled = true, destroyed = false, postCount = null, pinSignature = '', previousFocus;
    let hintTimer, announceTimer, postTarget = null;
    const settings = () => ({ ...FocusX.preferences?.defaults, ...getSettings() });
    function button(text, className, callback) {
      const node = document.createElement('button'); node.type = 'button'; node.className = className;
      node.textContent = text; node.addEventListener('click', callback); return node;
    }
    function sync(values = settings()) {
      if (destroyed || !document?.defaultView) return;
      host.dataset.theme = values.theme || 'system';
      host.dataset.enabled = String(enabled);
      shadow.querySelector('.type-scale').hidden = !enabled;
      shadow.querySelector('.post-navigation').hidden = !enabled || postCount === 0;
      shadow.querySelectorAll('[data-size]').forEach(node => node.setAttribute('aria-pressed', String(node.dataset.size === values.textSize)));
      const pins = values.pinnedNavigation || ['home', 'bookmarks'];
      if (pinSignature !== pins.join('|') || !pinned.childElementCount) {
        pinSignature = pins.join('|'); pinned.replaceChildren();
        for (const id of pins) {
          if (!titles[id]) continue;
          const node = button(titles[id], '', () => id === 'search' ? openSearch() : onCommand(id));
          node.dataset.command = id; pinned.append(node);
        }
        const add = button('+', 'customize', renderPins); add.setAttribute('aria-label', 'Customize pinned tabs'); pinned.append(add);
      }
      pinned.hidden = !enabled;
      const paths = { home: '/home', bookmarks: '/i/bookmarks', notifications: '/notifications', messages: '/messages', lists: '/i/lists', search: '/search' };
      const currentPath = location.pathname.replace(/\/$/, '') || '/';
      pinned.querySelectorAll('[data-command]').forEach(node => {
        const current = node.dataset.command === 'bookmarks'
          ? currentPath === '/i/history' || /^\/i\/bookmarks(?:\/\d+)?$/.test(currentPath)
          : paths[node.dataset.command] === currentPath;
        if (current) node.setAttribute('aria-current', 'page');
        else node.removeAttribute('aria-current');
      });
      dialog.querySelectorAll('[data-pin]').forEach(node => { node.checked = pins.includes(node.dataset.pin); });
      const original = dialog.querySelector('[name="original"]');
      if (original) original.checked = values.enabled === false;
      const dark = values.theme === 'dark' || values.theme === 'system' && globalThis.matchMedia?.('(prefers-color-scheme: dark)').matches;
      dialog.querySelectorAll('[data-theme-choice]').forEach(node => {
        node.setAttribute('aria-pressed', String(node.dataset.themeChoice === (dark ? 'dark' : 'light')));
      });
      accountButton.hidden = !enabled || !account?.element?.isConnected;
      const query = new URL(location.href).searchParams.get('q');
      const searchView = shadow.querySelector('.search-view');
      searchView.hidden = !enabled || location.pathname !== '/search' || !query;
      searchView.textContent = query ? `Search · ${query}` : '';
      searchView.title = 'Edit search';
      positionPostButton();
    }
    async function changeSetting(patch) {
      try { await onSettingsChange(patch); sync(); }
      catch { sync(); announce('That change could not be saved. Please try again.'); }
    }
    function announce(text) {
      clearTimeout(announceTimer);
      shadow.querySelector('.announcement').textContent = '';
      announceTimer = setTimeout(() => { shadow.querySelector('.announcement').textContent = text; }, 30);
    }
    function closeMenu() {
      if (dialog.open) dialog.close();
      const target = previousFocus?.isConnected ? previousFocus : menuButton;
      if (!destroyed) target?.focus({ preventScroll: true });
    }
    function showDialog(view, title, back = false) {
      if (!dialog.open) previousFocus = shadow.activeElement || document.activeElement;
      dialog.replaceChildren(); dialog.dataset.view = view;
      const row = document.createElement('div'); row.className = 'dialog-header';
      if (back) { const node = button('←', 'back', openMenu); node.setAttribute('aria-label', 'Back to reading menu'); row.append(node); }
      const heading = document.createElement('h2'); heading.id = 'focusx-dialog-title'; heading.textContent = title;
      const close = button('Esc', 'close', closeMenu); close.setAttribute('aria-label', view === 'search' ? 'Close search' : 'Close reading menu');
      row.append(heading, close); dialog.append(row);
      if (!dialog.open) dialog.showModal();
      expand.hidden = true;
      sync();
    }
    function searchForm(full = false) {
      const form = document.createElement('form'); form.className = 'search-form'; form.setAttribute('role', 'search');
      const field = document.createElement('div'); field.className = 'search-field'; field.innerHTML = searchIcon;
      const input = document.createElement('input'); input.className = 'search-input'; input.type = 'search';
      input.placeholder = full ? 'What are you looking for?' : 'Search X';
      input.setAttribute('aria-label', 'Search X'); input.autocomplete = 'off'; input.maxLength = 500;
      if (location.pathname === '/search') input.value = new URL(location.href).searchParams.get('q') || '';
      const submit = button('↗', 'search-submit', () => {}); submit.type = 'submit'; submit.setAttribute('aria-label', 'Submit search');
      submit.disabled = !input.value.trim(); input.addEventListener('input', () => { submit.disabled = !input.value.trim(); });
      field.append(input, submit); form.append(field);
      let filter = new URL(location.href).searchParams.get('f') === 'live' ? 'latest' : 'top';
      if (full) {
        const meta = document.createElement('div'); meta.className = 'search-meta';
        const choices = document.createElement('div'); choices.className = 'search-filters'; choices.setAttribute('role', 'group'); choices.setAttribute('aria-label', 'Search results order');
        for (const id of ['top', 'latest']) {
          const node = button(id === 'top' ? 'Top posts' : 'Latest', '', () => {
            filter = id; choices.querySelectorAll('button').forEach(item => item.setAttribute('aria-pressed', String(item === node)));
          });
          node.dataset.filter = id; node.setAttribute('aria-pressed', String(id === filter)); choices.append(node);
        }
        const key = document.createElement('kbd'); key.textContent = '↵ to search'; meta.append(choices, key);
        const note = document.createElement('p'); note.className = 'search-hint'; note.textContent = 'A thought, a person, a conversation. Try words, @handles, #topics, or from:username.';
        form.append(meta, note);
      }
      form.addEventListener('submit', event => {
        event.preventDefault(); const query = input.value.trim(); if (!query) { input.focus(); return; }
        closeMenu(); onSearch(query, filter);
      });
      dialog.append(form); input.focus({ preventScroll: true });
    }
    function openSearch() { showDialog('search', 'Search X'); searchForm(true); }
    function openMenu() {
      showDialog('menu', 'Reading menu'); searchForm();
      const list = document.createElement('div'); list.className = 'command-list';
      const pins = button('Customize pinned tabs', 'command', renderPins); pins.dataset.command = 'pins';
      const toggle = document.createElement('label'); toggle.className = 'interface-toggle';
      const toggleLabel = document.createElement('span'); toggleLabel.className = 'interface-label'; toggleLabel.textContent = 'Regular X interface';
      const toggleKey = document.createElement('kbd'); toggleKey.textContent = 'F'; toggleKey.setAttribute('aria-hidden', 'true'); toggleLabel.append(toggleKey); toggle.append(toggleLabel);
      const input = document.createElement('input'); input.type = 'checkbox'; input.name = 'original'; input.setAttribute('role', 'switch'); input.setAttribute('aria-label', 'Regular X interface'); input.checked = settings().enabled === false;
      input.addEventListener('change', () => changeSetting({ enabled: !input.checked })); toggle.append(input);
      const compose = button('Make a post', 'command', () => { closeMenu(); onCommand('compose'); }); compose.dataset.command = 'compose';
      const appearance = document.createElement('div'); appearance.className = 'appearance';
      const themeLabel = document.createElement('span'); themeLabel.textContent = 'Appearance';
      const themes = document.createElement('div'); themes.className = 'theme-choices'; themes.setAttribute('role', 'group'); themes.setAttribute('aria-label', 'Appearance');
      for (const [value, label] of [['dark', 'Black'], ['light', 'White']]) {
        const choice = button(label, '', () => changeSetting({ theme: value })); choice.dataset.themeChoice = value;
        const swatch = document.createElement('span'); swatch.className = `swatch swatch-${value}`; swatch.setAttribute('aria-hidden', 'true'); choice.prepend(swatch); themes.append(choice);
      }
      appearance.append(themeLabel, themes);
      list.append(pins, toggle, appearance, compose); dialog.append(list); sync();
    }
    function renderPins() {
      showDialog('pins', 'Customize pinned tabs', true);
      const list = document.createElement('div'); list.className = 'pin-list';
      for (const id of FocusX.preferences?.pinChoices || Object.keys(titles)) {
        const label = document.createElement('label'); label.textContent = titles[id];
        const input = document.createElement('input'); input.type = 'checkbox'; input.dataset.pin = id; input.checked = (settings().pinnedNavigation || []).includes(id);
        input.addEventListener('change', () => changeSetting({ pinnedNavigation: [...list.querySelectorAll('[data-pin]:checked')].map(node => node.dataset.pin) }));
        label.append(input); list.append(label);
      }
      dialog.append(list); list.querySelector('input')?.focus({ preventScroll: true });
    }
    function setAttributeIfChanged(node, name, value) {
      if (node.getAttribute(name) !== value) node.setAttribute(name, value);
    }
    function setHiddenIfChanged(node, value) {
      if (node.hidden !== value) node.hidden = value;
    }
    function positionPostButton() {
      const article = postTarget;
      if (!enabled || dialog.open || !article?.isConnected) { setHiddenIfChanged(expand, true); return; }
      const rect = article.getBoundingClientRect();
      setHiddenIfChanged(expand, rect.bottom < 120 || rect.top > innerHeight - 60);
      const top = `${Math.round(Math.max(76, rect.top + 12))}px`;
      const left = `${Math.round(Math.min(innerWidth - 48, rect.right - 36))}px`;
      if (expand.style.top !== top) expand.style.top = top;
      if (expand.style.left !== left) expand.style.left = left;
      const wide = article.classList.contains('fx-wide-post');
      const label = wide ? 'Restore post width' : 'Widen post';
      setAttributeIfChanged(expand, 'aria-label', label);
      setAttributeIfChanged(expand, 'title', `${label} (W)`);
      setAttributeIfChanged(expand, 'aria-pressed', String(wide));
    }
    function setAccount(value) {
      account = value?.element ? value : null;
      const imageUrl = account?.imageUrl || '';
      const label = account?.label || 'Open account menu';
      setAttributeIfChanged(accountButton, 'aria-label', label);
      setAttributeIfChanged(accountButton, 'title', label);
      if (accountImage !== imageUrl) {
        accountImage = imageUrl;
        accountButton.replaceChildren();
        if (imageUrl) {
          const image = document.createElement('img'); image.src = imageUrl; image.alt = '';
          image.addEventListener('error', () => { if (image.isConnected) accountButton.innerHTML = accountIcon; }, { once: true });
          accountButton.append(image);
        } else accountButton.innerHTML = accountIcon;
      }
      setHiddenIfChanged(accountButton, !enabled || !account?.element?.isConnected);
    }
    accountButton.addEventListener('click', () => { if (account?.element?.isConnected) account.element.click(); });
    function setPostTarget(article) { postTarget = article; positionPostButton(); }
    expand.addEventListener('click', () => { if (postTarget?.isConnected) { onExpand(postTarget); positionPostButton(); } });
    shadow.querySelectorAll('[data-size]').forEach(node => node.addEventListener('click', () => changeSetting({ textSize: node.dataset.size })));
    shadow.querySelectorAll('.post-navigation button').forEach(node => node.addEventListener('click', () => onCommand(node.dataset.command)));
    shadow.querySelector('.search-button').addEventListener('click', openSearch);
    shadow.querySelector('.search-view').addEventListener('click', openSearch);
    menuButton.addEventListener('click', openMenu);
    function hideHint() { clearTimeout(hintTimer); hint.hidden = true; }
    function showHint() { if (enabled) { hint.hidden = false; hintTimer = setTimeout(hideHint, 6500); } }
    hint.querySelector('button').addEventListener('click', hideHint);
    dialog.addEventListener('cancel', event => { event.preventDefault(); closeMenu(); });
    dialog.addEventListener('click', event => {
      if (event.target !== dialog) return;
      const rect = dialog.getBoundingClientRect();
      if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) closeMenu();
    });
    shadow.addEventListener('keydown', event => {
      if (!dialog.open) return;
      event.stopPropagation();
      if (event.key === 'Escape') { event.preventDefault(); closeMenu(); }
    });
    function setEnabled(value) { enabled = Boolean(value); if (!enabled) { hideHint(); postTarget = null; } sync(); }
    function setContext(context) {
      if (Number.isInteger(context?.total)) postCount = context.total;
      shadow.querySelector('.context').textContent = context?.index ? `Post ${context.index} of ${context.total} currently loaded` : context?.label || '';
      sync();
    }
    const unsubscribe = FocusX.preferences?.subscribe(sync);
    function destroy() { destroyed = true; unsubscribe?.(); clearTimeout(hintTimer); clearTimeout(announceTimer); if (dialog.open) dialog.close(); host.remove(); }
    document.documentElement.append(host); sync();
    return { host, setEnabled, setContext, setAccount, setPostTarget, positionPostButton, showHint, hideHint, announce, openMenu, openSearch, destroy };
  }
  FocusX.controls = { create };
})();
