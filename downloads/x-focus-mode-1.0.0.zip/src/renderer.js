/* Annotate X's live DOM without moving React-owned nodes or duplicating actions. */
(() => {
  'use strict';
  const FocusX = globalThis.FocusX = globalThis.FocusX || {};
  const records = new Map();
  const debugSignatures = new WeakMap();
  let pageRecord = new Map();

  function desired() { return new Map(); }
  function entry(plan, node) {
    if (!node?.classList) return null;
    if (!plan.has(node)) plan.set(node, { classes: new Set(), attributes: new Map(), styles: new Map() });
    return plan.get(node);
  }
  function tag(plan, node, ...classes) { const state = entry(plan, node); classes.forEach(name => state?.classes.add(name)); }
  function property(plan, node, name, value) { entry(plan, node)?.styles.set(name, String(value)); }
  function attribute(plan, node, name, value) { entry(plan, node)?.attributes.set(name, String(value)); }

  function restore(node, state, next) {
    for (const [name, originallyPresent] of state.classes) {
      if (!next?.classes.has(name) && !originallyPresent) node.classList.remove(name);
    }
    for (const [name, original] of state.styles) {
      if (next?.styles.has(name)) continue;
      if (original.value) node.style.setProperty(name, original.value, original.priority);
      else node.style.removeProperty(name);
    }
    for (const [name, original] of state.attributes) {
      if (next?.attributes.has(name)) continue;
      if (original === null) node.removeAttribute(name);
      else node.setAttribute(name, original);
    }
    if (!state.hadClassAttribute && !next?.classes.size && node.getAttribute('class') === '') node.removeAttribute('class');
    if (!state.hadStyleAttribute && !next?.styles.size && node.getAttribute('style') === '') node.removeAttribute('style');
  }

  function reconcile(previous, plan) {
    for (const [node, state] of previous) restore(node, state, plan.get(node));
    const nextRecord = new Map();
    for (const [node, wanted] of plan) {
      const old = previous.get(node);
      const state = {
        classes: new Map(), attributes: new Map(), styles: new Map(),
        hadClassAttribute: old ? old.hadClassAttribute : node.getAttribute('class') !== null,
        hadStyleAttribute: old ? old.hadStyleAttribute : node.getAttribute('style') !== null
      };
      for (const name of wanted.classes) {
        state.classes.set(name, old?.classes.has(name) ? old.classes.get(name) : node.classList.contains(name));
        if (!node.classList.contains(name)) node.classList.add(name);
      }
      for (const [name, value] of wanted.attributes) {
        state.attributes.set(name, old?.attributes.has(name) ? old.attributes.get(name) : node.getAttribute(name));
        if (node.getAttribute(name) !== value) node.setAttribute(name, value);
      }
      for (const [name, value] of wanted.styles) {
        state.styles.set(name, old?.styles.get(name) || { value: node.style.getPropertyValue(name), priority: node.style.getPropertyPriority(name) });
        if (node.style.getPropertyValue(name) !== value) node.style.setProperty(name, value);
      }
      nextRecord.set(node, state);
    }
    return nextRecord;
  }

  function chain(plan, node, article, className = 'fx-layout') {
    let cursor = node?.parentElement;
    while (cursor && cursor !== article && article.contains(cursor)) {
      tag(plan, cursor, className);
      cursor = cursor.parentElement;
    }
  }

  function commonParent(nodes, article) {
    const present = nodes.filter(Boolean);
    let parent = present[0]?.parentElement;
    while (parent && parent !== article) {
      if (present.every(node => parent.contains(node))) return parent;
      parent = parent.parentElement;
    }
    return null;
  }

  function metrics(model, prefs) {
    const length = [...model.text].length;
    const multiplier = { comfortable: 0.86, large: 1, huge: 1.13 }[String(prefs.textSize || prefs.size || 'large').toLowerCase()] || 1;
    // A smooth curve avoids a one-character change causing a conspicuous type jump.
    let size = 28 + 30 * Math.exp(-length / 280);
    if (model.media.length) size = Math.min(size, length < 160 ? 34 : 38);
    if (model.quote) size *= 0.88;
    return {
      size: `${(size * multiplier).toFixed(2)}px`,
      measure: `${length > 500 ? 1020 : 1320}px`,
      lineHeight: (length > 500 ? 1.3 : length > 280 ? 1.2 : 1.11).toString(),
      spacing: `${length < 100 && !model.media.length ? 110 : 80}px`
    };
  }

  function mediaGeometry(plan, model, body) {
    const photos = model.media.filter(item => item.type === 'photo').map(item => item.element);
    if (photos.length > 1) {
      const gallery = commonParent(photos, model.article);
      if (gallery && gallery !== body) {
        tag(plan, gallery, 'fx-gallery');
        attribute(plan, gallery, 'data-focusx-photos', photos.length);
      }
      return;
    }
    // Changing geometry under an interstitial could displace its warning cover.
    if (photos.length !== 1 || model.media.length !== 1 || model.sensitive) return;
    const photo = photos[0];
    const images = [...photo.querySelectorAll('img')];
    if (images.length !== 1) return;
    const image = images[0];
    const protectedNodes = [model.authorElement, model.textElement, model.actionRow, model.quote, model.poll, model.card, model.context, ...(model.notes || [])].filter(Boolean);
    const safeContainer = node => node && node !== model.article && node !== body
      && !protectedNodes.some(protectedNode => node.contains(protectedNode))
      && !node.querySelector(FocusX.adapter.selectors.sensitive);
    tag(plan, photo, 'fx-single-photo');
    let outer = photo;
    let cursor = photo.parentElement;
    while (safeContainer(cursor)) {
      tag(plan, cursor, 'fx-single-photo-layout');
      outer = cursor;
      cursor = cursor.parentElement;
    }
    cursor = image.parentElement;
    while (cursor && cursor !== photo && photo.contains(cursor)) {
      tag(plan, cursor, 'fx-photo-surface');
      cursor = cursor.parentElement;
    }
    // X creates image ratios with empty padding spacers. Remove only that geometry,
    // leaving overlays, accessible labels, filters, and image interactions intact.
    outer.querySelectorAll('div').forEach(node => {
      if (node.childElementCount || node.textContent.trim()) return;
      const padding = node.style.paddingBottom || node.style.paddingTop;
      if (padding && /^\d+(?:\.\d+)?%$/.test(padding)) tag(plan, node, 'fx-photo-spacer');
    });
  }

  function decorate(model, prefs = {}) {
    const { article, authorElement, textElement, actionRow } = model;
    if (!article) return model;
    const plan = desired();
    const scale = metrics(model, prefs);
    tag(plan, article, 'fx-post');
    if (model.media.length) tag(plan, article, 'fx-has-media');
    if (model.quote) tag(plan, article, 'fx-has-quote');
    if (model.text.length > 500) tag(plan, article, 'fx-long-post');
    if (model.text.length < 100 && !model.media.length) tag(plan, article, 'fx-short-post');
    if (model.promoted) tag(plan, article, 'fx-promoted');
    attribute(plan, article, 'data-focusx-processed', 'true');
    property(plan, article, '--fx-type-size', scale.size);
    property(plan, article, '--fx-text-measure', scale.measure);
    property(plan, article, '--fx-line-height', scale.lineHeight);
    property(plan, article, '--fx-post-space', scale.spacing);
    property(plan, article, '--fx-image-count', model.media.filter(item => item.type === 'photo').length);
    tag(plan, model.cell, 'fx-cell');
    tag(plan, textElement, 'fx-text');
    tag(plan, authorElement, 'fx-author');
    tag(plan, model.menu, 'fx-post-menu');
    const authorRow = model.menu ? commonParent([authorElement, model.menu], article) : null;
    if (authorRow && !authorRow.contains(textElement) && !authorRow.contains(actionRow)) tag(plan, authorRow, 'fx-author-row');
    tag(plan, actionRow, 'fx-actions');
    tag(plan, model.context, 'fx-context');
    tag(plan, model.promotedLabel, 'fx-promoted-label');
    tag(plan, model.avatar, 'fx-avatar');
    tag(plan, model.poll, 'fx-poll');
    tag(plan, model.card, 'fx-link-card');
    tag(plan, model.sensitive, 'fx-sensitive');
    for (const node of [authorElement, textElement, actionRow, model.context, model.poll, model.card, model.quote]) chain(plan, node, article);
    const body = commonParent([authorElement, textElement, actionRow], article);
    tag(plan, body, 'fx-body');
    if (body && model.avatar) {
      let avatarColumn = model.avatar;
      while (avatarColumn.parentElement && avatarColumn.parentElement !== body.parentElement && avatarColumn.parentElement !== article) avatarColumn = avatarColumn.parentElement;
      if (avatarColumn !== article && !avatarColumn.contains(body)) tag(plan, avatarColumn, 'fx-avatar-column');
    }
    for (const item of model.media) {
      tag(plan, item.element, 'fx-media', item.type === 'photo' ? 'fx-photo' : 'fx-video');
      chain(plan, item.element, article, 'fx-media-layout');
      if (item.type === 'photo') item.element.querySelectorAll('img').forEach(image => tag(plan, image, 'fx-photo-image'));
    }
    mediaGeometry(plan, model, body);
    for (const quote of model.quotes || (model.quote ? [model.quote] : [])) {
      tag(plan, quote, 'fx-quote');
      quote.querySelectorAll(FocusX.adapter.selectors.text).forEach(text => tag(plan, text, 'fx-quote-text'));
      quote.querySelectorAll(FocusX.adapter.selectors.author).forEach(author => tag(plan, author, 'fx-quote-author'));
    }
    for (const note of model.notes || []) tag(plan, note, 'fx-note');
    records.set(article, reconcile(records.get(article) || new Map(), plan));
    if (prefs.debug) {
      const structure = {
        postId: model.id || null, characters: [...model.text].length,
        author: Boolean(model.authorElement), media: model.media.map(item => item.type),
        quotes: model.quotes?.length || 0, poll: Boolean(model.poll),
        notes: model.notes?.length || 0, sensitive: Boolean(model.sensitive), promoted: Boolean(model.promoted),
        actions: Object.keys(model.actions || {}).filter(key => model.actions[key])
      };
      const signature = JSON.stringify(structure);
      if (debugSignatures.get(article) !== signature) {
        console.debug('[Focus] Parsed post structure', structure);
        debugSignatures.set(article, signature);
      }
    } else debugSignatures.delete(article);
    return model;
  }

  function clear(article) {
    const record = records.get(article);
    if (!record) return;
    reconcile(record, new Map());
    records.delete(article);
    debugSignatures.delete(article);
  }

  function clearAll() { for (const article of records.keys()) clear(article); }

  function preparePage(primary) {
    if (!primary) { clearPage(); return; }
    const plan = desired();
    const adapter = FocusX.adapter;
    const refreshControls = adapter.findTimelineRefresh(primary);
    // X's posting toolbar uses tablist semantics too. Only genuine timeline
    // navigation should stop a composer walk or become a retained library tab.
    const timelineTabs = [...primary.querySelectorAll('[role="tablist"]')]
      .filter(node => !node.closest(adapter.selectors.composerToolbar));
    const containsTimelineTabs = node => timelineTabs.some(tabs => node === tabs || node.contains(tabs));
    const libraryTabs = adapter.getRoute().path === '/i/history'
      ? timelineTabs.filter(node => !node.closest(`${adapter.selectors.article}, [role="region"], [role="dialog"], [aria-modal="true"]`))
      : [];
    const containsLibraryTabs = node => libraryTabs.some(tabs => node === tabs || node.contains(tabs));
    for (const tabs of libraryTabs) {
      tag(plan, tabs, 'fx-library-tabs');
      let container = tabs.parentElement;
      while (container && container !== primary
        && !container.querySelector(`${adapter.selectors.article}, ${adapter.selectors.timelineState}, [role="region"]`)) {
        tag(plan, container, 'fx-library-layout');
        container = container.parentElement;
      }
    }
    tag(plan, primary, 'fx-primary');
    // Reset horizontal sizing only along live timeline paths. Native virtualizer
    // heights, transforms, positioning and every post/action node remain intact.
    const timelineAnchors = [...primary.querySelectorAll(adapter.selectors.article)]
      .filter(node => !node.closest('[role="dialog"], [aria-modal="true"]') && !node.parentElement?.closest(adapter.selectors.article));
    timelineAnchors.push(...primary.querySelectorAll(adapter.selectors.timelineState));
    for (const anchor of timelineAnchors) {
      if (anchor.closest('[role="dialog"], [aria-modal="true"]') || anchor.closest(adapter.selectors.article) && !anchor.matches(adapter.selectors.article)) continue;
      let wrapper = anchor.parentElement;
      while (wrapper && wrapper !== primary && primary.contains(wrapper)) {
        tag(plan, wrapper, 'fx-timeline-layout');
        wrapper = wrapper.parentElement;
      }
    }
    refreshControls.forEach(node => tag(plan, node, 'fx-timeline-refresh'));
    primary.querySelectorAll(FocusX.adapter.selectors.timelineState).forEach(node => {
      if (!node.closest(FocusX.adapter.selectors.article)) tag(plan, node, 'fx-timeline-state');
    });
    let cursor = primary.parentElement;
    while (cursor && cursor !== document.body && cursor !== document.documentElement) {
      tag(plan, cursor, 'fx-page-layout');
      cursor = cursor.parentElement;
    }
    document.querySelectorAll(`${FocusX.adapter.selectors.sidebar}, header[role="banner"]`).forEach(node => tag(plan, node, 'fx-native-chrome'));
    // Native X app bars are often nested divs. Walk from semantic/stable anchors,
    // never beyond a container that also owns actual posts or the compose form.
    const firstContent = primary.querySelector(`${adapter.selectors.article}, ${adapter.selectors.timelineState}, [role="region"]`);
    const hideHeaderSection = anchor => {
      const containsContent = node => containsLibraryTabs(node) || node.querySelector(`${adapter.selectors.article}, ${adapter.selectors.composer}, ${adapter.selectors.timelineState}, [role="region"]`)
        || refreshControls.some(control => node === control || node.contains(control));
      if (anchor.closest(`${adapter.selectors.article}, [role="dialog"], [aria-modal="true"], ${adapter.selectors.timelineState}, ${adapter.selectors.composerToolbar}`)
        || containsContent(anchor)) return;
      let section = anchor;
      while (section.parentElement && section.parentElement !== primary
        && primary.contains(section.parentElement)
        && !section.parentElement.matches('[role="region"]')
        && !containsContent(section.parentElement)) section = section.parentElement;
      tag(plan, section, 'fx-native-chrome');
    };
    primary.querySelectorAll(FocusX.adapter.selectors.pageHeader).forEach(hideHeaderSection);
    // Mobile X may render an avatar-only app bar with no heading or back button.
    primary.querySelectorAll(adapter.selectors.account).forEach(hideHeaderSection);
    const primaryAccount = adapter.findAccount(primary);
    if (primaryAccount) hideHeaderSection(primaryAccount.element);
    primary.querySelectorAll(FocusX.adapter.selectors.pageHeading).forEach(heading => {
      if (firstContent && (heading.compareDocumentPosition(firstContent) & 4)) hideHeaderSection(heading);
    });
    const composers = [...primary.querySelectorAll(adapter.selectors.composer)].filter(node =>
      !node.closest(`${adapter.selectors.article}, [role="dialog"], [aria-modal="true"]`));
    for (const composer of composers) {
      // A submit loader can keep an otherwise empty composer wrapper mounted.
      // Neutralize only its surface; keep every size, position and loader intact.
      const shellBoundary = `${adapter.selectors.article}, [role="region"], [role="dialog"], [aria-modal="true"]`;
      let shell = composer.parentElement;
      while (shell && shell !== primary && primary.contains(shell)
        && !shell.matches(shellBoundary) && !shell.querySelector(shellBoundary) && !containsTimelineTabs(shell)) {
        tag(plan, shell, 'fx-composer-shell');
        shell = shell.parentElement;
      }
      const containsTimeline = node => containsTimelineTabs(node) || node.querySelector(`${adapter.selectors.article}, ${adapter.selectors.timelineState}, [role="region"]`)
        || refreshControls.some(control => node === control || node.contains(control));
      const composerCell = composer.closest(adapter.selectors.cell);
      if (composerCell && !containsTimeline(composerCell)) tag(plan, composerCell, 'fx-native-chrome');
      else {
        let composerSection = composer;
        while (composerSection.parentElement && composerSection.parentElement !== primary
          && !composerSection.parentElement.matches('[role="region"]')
          && !containsTimeline(composerSection.parentElement)) composerSection = composerSection.parentElement;
        tag(plan, composerSection, 'fx-native-chrome');
      }
    }
    pageRecord = reconcile(pageRecord, plan);
  }

  function clearPage() { pageRecord = reconcile(pageRecord, new Map()); }

  FocusX.renderer = Object.freeze({ decorate, clear, clearAll, preparePage, clearPage });
})();
