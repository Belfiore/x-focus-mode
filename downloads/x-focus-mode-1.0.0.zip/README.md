# X Focus Mode

## Install or update

1. Unzip the package if needed.
2. Open `chrome://extensions` and enable **Developer mode**.
3. Choose **Load unpacked** and select this directory, which contains `manifest.json`.
4. Open X while signed into your normal account.
5. For an update, replace files in the already loaded directory, reload the extension in Chrome, then refresh every open X tab. Otherwise those tabs keep the old injected scripts.

No build step or separate login is required.

## Use

One reading experience: scroll normally or use **↓ / ↑** to move directly between posts. **J / K / Space** read through long posts. **Enter** opens a post; **L / B / R** use the native like, bookmark and reply controls. Shortcuts pause while typing.

**Home** and **Bookmarks** start pinned at the left, and Bookmarks uses the same custom layout. **+** chooses pinned tabs. Your account circle floats at the top left when available; previous/next arrows sit at the bottom left. The three **A** buttons change text size. Hover over a post to reveal **Widen post**, then click it to expand or restore the width; **W** does the same from the keyboard. Hovering itself keeps the post width stable.

The magnifying glass beside **···** opens search with **Top posts / Latest** choices. **Cmd/Ctrl K** or **/** also opens search. Results use the reading layout. The menu contains search, pin customization, the visible **Regular X interface** switch, **Black / White** appearance choices and **Make a post**. **C** opens compose, and a single tap of **F** switches between custom and regular X. There is one reading mode in either appearance. The extension icon opens appearance and other preferences.

Only local preferences are saved. There is no backend, analytics, cookie access or timeline storage. Real posts, saved items, search results and social actions remain owned by X.

## Verification

Version 1.0.0 passes 72 automated tests in the full source package, including staged Bookmarks loading, hover stability and plain-F switching. Authenticated Chrome checks verified skinned Home and Bookmarks after X’s `/i/history` redirect, F in both directions, next-post navigation, stable Black/White changes, the visible menu switch, floating profile and arrow placement. The final Home reload confirmed that the black composer strip is gone. Broader compatibility checks are listed in the source package’s `QA.md`. X layouts vary across accounts and experiments. Unsupported pages use the original interface. F or the menu switch restores original X whenever needed.

X-specific selectors are centralized in `src/adapter.js`. The full source package also includes the sample preview server, tests and QA notes.
