(() => {
  'use strict';
  const { preferences } = globalThis.FocusX;
  const form = document.querySelector('#preferences');
  const status = document.querySelector('#save-status');
  let statusTimer;
  const titles = { home: 'Home', following: 'Following', bookmarks: 'Bookmarks', notifications: 'Notifications', messages: 'Messages', lists: 'Lists', profile: 'Profile', search: 'Search' };
  for (const id of preferences.pinChoices) {
    const row = document.createElement('div');
    row.className = 'preference';
    const label = document.createElement('label');
    label.htmlFor = `pin-${id}`;
    label.textContent = titles[id];
    const input = document.createElement('input');
    input.id = label.htmlFor;
    input.type = 'checkbox';
    input.dataset.pin = id;
    row.append(label, input);
    document.querySelector('#pinned-settings').append(row);
  }

  function render(settings) {
    for (const field of form.elements) {
      if (!field.name || !(field.name in settings)) continue;
      if (field.type === 'checkbox') field.checked = settings[field.name];
      else field.value = settings[field.name];
    }
    form.querySelectorAll('[data-pin]').forEach(field => { field.checked = settings.pinnedNavigation.includes(field.dataset.pin); });
    document.documentElement.dataset.theme = settings.theme;
  }

  form.addEventListener('submit', event => event.preventDefault());
  form.addEventListener('change', async event => {
    const field = event.target;
    if (!field.dataset.pin && (!field.name || !(field.name in preferences.defaults))) return;
    clearTimeout(statusTimer);
    const value = field.type === 'checkbox' ? field.checked : field.value;
    try {
      const patch = field.dataset.pin ? { pinnedNavigation: [...form.querySelectorAll('[data-pin]:checked')].map(input => input.dataset.pin) } : { [field.name]: value };
      const settings = await preferences.save(patch);
      render(settings);
      status.dataset.error = 'false';
      status.textContent = 'Saved on this device.';
      statusTimer = setTimeout(() => { status.textContent = 'Preferences stay on this device.'; }, 2400);
    } catch {
      status.dataset.error = 'true';
      status.textContent = 'That change could not be saved. Please reopen X Focus Mode and try again.';
      render(await preferences.load());
    }
  });
  preferences.subscribe(render);
  preferences.load().then(render);
})();
